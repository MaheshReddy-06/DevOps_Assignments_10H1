# Student Management Dashboard

Built for Assignment 7.2.2 (DevOps and Fullstack, Scenario 2).

## Setup

```
npm install
npm run dev
```

Open the printed `localhost` URL. For a production build: `npm run build`.

## Project structure

```
src/
  main.jsx              entry point, mounts <App />
  App.jsx               top-level layout, holds selected-student state
  App.css                dashboard styling
  index.css              global reset/base styles
  data/students.js       sample data (3 students) with subjects + exams
  utils/eligibility.js   shared 75%-attendance eligibility rule
  components/
    Header.jsx           college name + app title
    StudentProfile.jsx    name, roll number, branch, year (via props)
    SubjectList.jsx       subjects list, rendered with .map()
    Attendance.jsx        attendance %, progress bar, eligibility pill
    ExamDetails.jsx       exam table (subject / type / date)
    Footer.jsx             copyright line
    StudentCard.jsx        bonus: roster card, "View Profile" button,
                            conditional Eligible/Not Eligible rendering
```

## How it maps to the task list

- **Project setup / config** — standard Vite + React scaffold (`vite.config.js`, `index.html`), default content replaced with "Student Management Dashboard".
- **Component development** — one component per requirement, each in its own file under `src/components/`.
- **Component operations** — `App.jsx` imports every component, passes the selected student's data down as props, and uses `subjects.map()` / `exams.map()` to render lists.
- **Advanced operations** — separate `components/` folder, individual `.jsx` files, single `App.css` for styling, attendance renders dynamically from state.
- **Bonus challenge** — `StudentCard` shows a "View Profile" button that swaps which student is loaded in the dashboard above (`onViewProfile` prop lifts state up to `App`), and conditionally renders "Eligible" / "Not Eligible" based on the 75% threshold in `utils/eligibility.js`.

## Extending it

Swap the static array in `data/students.js` for a `fetch()`/`axios` call to a real backend — none of the components need to change, since they only consume props.
