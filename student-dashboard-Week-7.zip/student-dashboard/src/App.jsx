import { useState } from 'react'
import Header from './components/Header.jsx'
import StudentProfile from './components/StudentProfile.jsx'
import SubjectList from './components/SubjectList.jsx'
import Attendance from './components/Attendance.jsx'
import ExamDetails from './components/ExamDetails.jsx'
import StudentCard from './components/StudentCard.jsx'
import Footer from './components/Footer.jsx'
import students from './data/students.js'
import './App.css'

const COLLEGE_NAME = 'SR University'

function App() {
  const [selectedId, setSelectedId] = useState(students[0].id)
  const selectedStudent = students.find((s) => s.id === selectedId)

  return (
    <div className="dashboard">
      <Header collegeName={COLLEGE_NAME} appTitle="Student Management Dashboard" />

      <main className="dashboard__main">
        <div className="dashboard__grid">
          <div className="dashboard__column dashboard__column--narrow">
            <StudentProfile student={selectedStudent} />
            <Attendance percentage={selectedStudent.attendance} />
          </div>
          <div className="dashboard__column dashboard__column--wide">
            <SubjectList subjects={selectedStudent.subjects} />
            <ExamDetails exams={selectedStudent.exams} />
          </div>
        </div>

        <section className="roster">
          <h3 className="card__heading">Class Roster</h3>
          <p className="roster__hint">Select a student to load their profile above.</p>
          <div className="roster__grid">
            {students.map((student) => (
              <StudentCard
                key={student.id}
                student={student}
                isActive={student.id === selectedId}
                onViewProfile={setSelectedId}
              />
            ))}
          </div>
        </section>
      </main>

      <Footer collegeName={COLLEGE_NAME} />
    </div>
  )
}

export default App
