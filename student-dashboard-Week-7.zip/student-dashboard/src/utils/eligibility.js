// A student is exam-eligible at 75% attendance or above — the common
// minimum threshold used by most Indian universities/colleges.
export const ELIGIBILITY_THRESHOLD = 75

export function isEligible(attendancePercentage) {
  return attendancePercentage >= ELIGIBILITY_THRESHOLD
}
