// Sample data. In a real system this would come from an API —
// swap the fetch for a real request and the components won't need to change.
const students = [
  {
    id: 'stu-001',
    name: 'Mahesh Reddy Kashireddy',
    rollNumber: '21R11A0512',
    branch: 'Computer Science & Engineering',
    year: '3rd Year',
    attendance: 88,
    subjects: [
      { id: 1, name: 'DevOps & Fullstack Development', credits: 4 },
      { id: 2, name: 'Machine Learning', credits: 4 },
      { id: 3, name: 'Computer Networks', credits: 3 },
      { id: 4, name: 'Software Engineering', credits: 3 },
      { id: 5, name: 'Constitution of India', credits: 2 },
    ],
    exams: [
      { id: 1, subject: 'DevOps & Fullstack Development', date: '2026-10-12', type: 'Mid Term' },
      { id: 2, subject: 'Machine Learning', date: '2026-10-14', type: 'Mid Term' },
      { id: 3, subject: 'Computer Networks', date: '2026-10-16', type: 'Mid Term' },
    ],
  },
  {
    id: 'stu-002',
    name: 'Ananya Verma',
    rollNumber: '21R11A0533',
    branch: 'Computer Science & Engineering',
    year: '3rd Year',
    attendance: 69,
    subjects: [
      { id: 1, name: 'DevOps & Fullstack Development', credits: 4 },
      { id: 2, name: 'Machine Learning', credits: 4 },
      { id: 3, name: 'Computer Networks', credits: 3 },
    ],
    exams: [
      { id: 1, subject: 'DevOps & Fullstack Development', date: '2026-10-12', type: 'Mid Term' },
      { id: 2, subject: 'Machine Learning', date: '2026-10-14', type: 'Mid Term' },
    ],
  },
  {
    id: 'stu-003',
    name: 'Rohit Palle',
    rollNumber: '21R11A0547',
    branch: 'Computer Science & Engineering',
    year: '3rd Year',
    attendance: 92,
    subjects: [
      { id: 1, name: 'DevOps & Fullstack Development', credits: 4 },
      { id: 2, name: 'Machine Learning', credits: 4 },
      { id: 3, name: 'Computer Networks', credits: 3 },
      { id: 4, name: 'Software Engineering', credits: 3 },
    ],
    exams: [
      { id: 1, subject: 'DevOps & Fullstack Development', date: '2026-10-12', type: 'Mid Term' },
      { id: 2, subject: 'Machine Learning', date: '2026-10-14', type: 'Mid Term' },
      { id: 3, subject: 'Software Engineering', date: '2026-10-18', type: 'Mid Term' },
    ],
  },
]

export default students
