function ExamDetails({ exams }) {
  return (
    <section className="card">
      <h3 className="card__heading">Examination Details</h3>
      {exams.length === 0 ? (
        <p className="exam-empty">No exams scheduled yet.</p>
      ) : (
        <table className="exam-table">
          <thead>
            <tr>
              <th>Subject</th>
              <th>Type</th>
              <th>Date</th>
            </tr>
          </thead>
          <tbody>
            {exams.map((exam) => (
              <tr key={exam.id}>
                <td>{exam.subject}</td>
                <td>{exam.type}</td>
                <td>{exam.date}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </section>
  )
}

export default ExamDetails
