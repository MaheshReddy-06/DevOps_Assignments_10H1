function SubjectList({ subjects }) {
  return (
    <section className="card">
      <h3 className="card__heading">Subjects</h3>
      <ul className="subject-list">
        {subjects.map((subject) => (
          <li key={subject.id} className="subject-list__row">
            <span>{subject.name}</span>
            <span className="subject-list__credits">{subject.credits} cr</span>
          </li>
        ))}
      </ul>
    </section>
  )
}

export default SubjectList
