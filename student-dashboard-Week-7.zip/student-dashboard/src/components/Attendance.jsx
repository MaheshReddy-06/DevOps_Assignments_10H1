import { isEligible, ELIGIBILITY_THRESHOLD } from '../utils/eligibility.js'

function Attendance({ percentage }) {
  const eligible = isEligible(percentage)

  return (
    <section className="card">
      <h3 className="card__heading">Attendance</h3>
      <div className="attendance">
        <span className="attendance__value">{percentage}%</span>
        <div className="attendance__track" role="progressbar" aria-valuenow={percentage} aria-valuemin={0} aria-valuemax={100}>
          <div
            className={`attendance__fill ${eligible ? 'attendance__fill--ok' : 'attendance__fill--low'}`}
            style={{ width: `${percentage}%` }}
          />
        </div>
        <span className={`status-pill ${eligible ? 'status-pill--ok' : 'status-pill--low'}`}>
          {eligible ? 'Eligible' : 'Not Eligible'}
        </span>
      </div>
      <p className="attendance__note">Minimum required for exam eligibility: {ELIGIBILITY_THRESHOLD}%</p>
    </section>
  )
}

export default Attendance
