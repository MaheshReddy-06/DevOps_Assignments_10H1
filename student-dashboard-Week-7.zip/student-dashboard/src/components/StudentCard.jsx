import { isEligible } from '../utils/eligibility.js'

function StudentCard({ student, isActive, onViewProfile }) {
  const eligible = isEligible(student.attendance)

  return (
    <article className={`roster-card ${isActive ? 'roster-card--active' : ''}`}>
      <div className="roster-card__avatar" aria-hidden="true">{student.name.charAt(0)}</div>
      <h4 className="roster-card__name">{student.name}</h4>
      <p className="roster-card__roll">{student.rollNumber}</p>
      <p className="roster-card__attendance">{student.attendance}% attendance</p>

      {/* Conditional rendering based on attendance */}
      <span className={`status-pill ${eligible ? 'status-pill--ok' : 'status-pill--low'}`}>
        {eligible ? 'Eligible' : 'Not Eligible'}
      </span>

      <button className="roster-card__button" onClick={() => onViewProfile(student.id)}>
        {isActive ? 'Viewing Profile' : 'View Profile'}
      </button>
    </article>
  )
}

export default StudentCard
