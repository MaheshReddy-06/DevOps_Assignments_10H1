function Footer({ collegeName }) {
  const year = new Date().getFullYear()

  return (
    <footer className="app-footer">
      <p>© {year} {collegeName}. All rights reserved.</p>
    </footer>
  )
}

export default Footer
