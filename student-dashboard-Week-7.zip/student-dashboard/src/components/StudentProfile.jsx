function StudentProfile({ student }) {
  const initial = student.name.charAt(0)

  return (
    <section className="card profile-card">
      <div className="profile-card__avatar" aria-hidden="true">{initial}</div>
      <h2 className="profile-card__name">{student.name}</h2>
      <dl className="profile-card__details">
        <div>
          <dt>Roll Number</dt>
          <dd>{student.rollNumber}</dd>
        </div>
        <div>
          <dt>Branch</dt>
          <dd>{student.branch}</dd>
        </div>
        <div>
          <dt>Year</dt>
          <dd>{student.year}</dd>
        </div>
      </dl>
    </section>
  )
}

export default StudentProfile
