function Header({ collegeName, appTitle }) {
  return (
    <header className="app-header">
      <div className="app-header__mark">SR</div>
      <div>
        <p className="app-header__college">{collegeName}</p>
        <h1 className="app-header__title">{appTitle}</h1>
      </div>
    </header>
  )
}

export default Header
