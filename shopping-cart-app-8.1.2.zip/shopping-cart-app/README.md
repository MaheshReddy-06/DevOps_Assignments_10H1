# Shopping Cart App (Assignment 8.1.2)

React app built with Vite, using **props** to pass data between components
and **useState** to manage the shopping cart.

## Setup

1. Make sure Node.js is installed.
2. Unzip this project, then in the project folder run:
   ```
   npm install
   npm run dev
   ```
3. Open the local URL Vite prints (usually `http://localhost:5173`).

## Component structure

- `App.jsx` — holds the `cart` state (single source of truth) and passes it
  down as props to the components below.
- `Header.jsx` — receives `cartItemCount` as a prop, shows it as a badge.
- `ProductList.jsx` — receives `products` and `onAddToCart`, renders a
  `ProductCard` for each product.
- `ProductCard.jsx` — receives one `product` + `onAddToCart`, has its own
  local quantity state, +/− controls, and an "Added to cart!" message.
- `Cart.jsx` — receives `cartItems`, `onRemove`, `onClear`; computes and
  displays the total price, shows "Cart is Empty" when there's nothing in it.
- `Footer.jsx` — static app info.

## Requirements covered

- Props: product info ProductList → ProductCard, cart count App → Header,
  cart items App → Cart.
- State: `useState` in `App` for the cart array, `useState` in `ProductCard`
  for per-product quantity.
- Add to cart, remove from cart, dynamic cart count, dynamic total price,
  "Cart is Empty" message.
- Bonus: quantity +/− controls, total price by quantity, Clear Cart button,
  "Added to cart!" confirmation message.
