const products = [
  {
    id: 1,
    name: "Wireless Headphones",
    price: 1499,
    image: "https://picsum.photos/seed/headphones/200/200",
  },
  {
    id: 2,
    name: "Smart Watch",
    price: 2999,
    image: "https://picsum.photos/seed/smartwatch/200/200",
  },
  {
    id: 3,
    name: "Bluetooth Speaker",
    price: 1199,
    image: "https://picsum.photos/seed/speaker/200/200",
  },
  {
    id: 4,
    name: "Mechanical Keyboard",
    price: 2499,
    image: "https://picsum.photos/seed/keyboard/200/200",
  },
  {
    id: 5,
    name: "Wireless Mouse",
    price: 699,
    image: "https://picsum.photos/seed/mouse/200/200",
  },
  {
    id: 6,
    name: "USB-C Hub",
    price: 899,
    image: "https://picsum.photos/seed/usbhub/200/200",
  },
];

export default products;
