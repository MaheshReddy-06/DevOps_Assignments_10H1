import { useState } from "react";

// ProductCard receives a single product's info via props from ProductList,
// plus an onAddToCart callback used to lift the "add" event back up to App.
function ProductCard({ product, onAddToCart }) {
  const [quantity, setQuantity] = useState(1);
  const [justAdded, setJustAdded] = useState(false);

  const increment = () => setQuantity((q) => q + 1);
  const decrement = () => setQuantity((q) => Math.max(1, q - 1));

  const handleAddToCart = () => {
    onAddToCart(product, quantity);
    setQuantity(1);
    setJustAdded(true);
    setTimeout(() => setJustAdded(false), 1500);
  };

  return (
    <div className="product-card">
      <img src={product.image} alt={product.name} className="product-card__image" />
      <h3 className="product-card__name">{product.name}</h3>
      <p className="product-card__price">₹{product.price.toLocaleString("en-IN")}</p>

      <div className="product-card__quantity">
        <button onClick={decrement} aria-label={`Decrease quantity of ${product.name}`}>
          −
        </button>
        <span>{quantity}</span>
        <button onClick={increment} aria-label={`Increase quantity of ${product.name}`}>
          +
        </button>
      </div>

      <button className="product-card__add-btn" onClick={handleAddToCart}>
        Add to Cart
      </button>

      {justAdded && <p className="product-card__added-msg">Added to cart!</p>}
    </div>
  );
}

export default ProductCard;
