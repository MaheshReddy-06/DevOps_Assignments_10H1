import ProductCard from "./ProductCard";

// ProductList receives the full products array and the onAddToCart
// callback from App, and passes each product down to a ProductCard.
function ProductList({ products, onAddToCart }) {
  return (
    <section className="product-list">
      <h2 className="product-list__title">Products</h2>
      <div className="product-list__grid">
        {products.map((product) => (
          <ProductCard key={product.id} product={product} onAddToCart={onAddToCart} />
        ))}
      </div>
    </section>
  );
}

export default ProductList;
