// Header receives the cart item count as a prop from App (parent)
// and displays it as a small badge next to the app name/logo.
function Header({ cartItemCount }) {
  return (
    <header className="header">
      <h1 className="header__title">🛒 Online Shopping</h1>
      <div className="header__cart-badge">
        Cart
        <span className="header__count">{cartItemCount}</span>
      </div>
    </header>
  );
}

export default Header;
