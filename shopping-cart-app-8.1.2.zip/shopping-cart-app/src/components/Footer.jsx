function Footer() {
  return (
    <footer className="footer">
      <p>© {new Date().getFullYear()} Online Shopping App — built with React (props &amp; state)</p>
    </footer>
  );
}

export default Footer;
