// Cart receives the current cart items and two callbacks (onRemove, onClear)
// from App. It computes and displays the total price based on quantity.
function Cart({ cartItems, onRemove, onClear }) {
  const totalPrice = cartItems.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );

  return (
    <section className="cart">
      <h2 className="cart__title">Your Cart</h2>

      {cartItems.length === 0 ? (
        <p className="cart__empty">Cart is Empty</p>
      ) : (
        <>
          <ul className="cart__list">
            {cartItems.map((item) => (
              <li key={item.id} className="cart__item">
                <img src={item.image} alt={item.name} className="cart__item-image" />
                <div className="cart__item-info">
                  <p className="cart__item-name">{item.name}</p>
                  <p className="cart__item-meta">
                    ₹{item.price.toLocaleString("en-IN")} × {item.quantity} = ₹
                    {(item.price * item.quantity).toLocaleString("en-IN")}
                  </p>
                </div>
                <button
                  className="cart__remove-btn"
                  onClick={() => onRemove(item.id)}
                  aria-label={`Remove ${item.name} from cart`}
                >
                  Remove
                </button>
              </li>
            ))}
          </ul>

          <div className="cart__footer">
            <p className="cart__total">Total: ₹{totalPrice.toLocaleString("en-IN")}</p>
            <button className="cart__clear-btn" onClick={onClear}>
              Clear Cart
            </button>
          </div>
        </>
      )}
    </section>
  );
}

export default Cart;
