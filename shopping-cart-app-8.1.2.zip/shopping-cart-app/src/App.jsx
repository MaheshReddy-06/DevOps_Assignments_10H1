import { useState } from "react";
import Header from "./components/Header";
import ProductList from "./components/ProductList";
import Cart from "./components/Cart";
import Footer from "./components/Footer";
import products from "./data/products";
import "./App.css";

function App() {
  // Single source of truth for the cart lives here in App, and is
  // passed down to Header (count), ProductList (add handler), and
  // Cart (items + remove/clear handlers) via props.
  const [cart, setCart] = useState([]);

  const handleAddToCart = (product, quantity) => {
    setCart((prevCart) => {
      const existing = prevCart.find((item) => item.id === product.id);
      if (existing) {
        return prevCart.map((item) =>
          item.id === product.id
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [...prevCart, { ...product, quantity }];
    });
  };

  const handleRemoveFromCart = (productId) => {
    setCart((prevCart) => prevCart.filter((item) => item.id !== productId));
  };

  const handleClearCart = () => setCart([]);

  const cartItemCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <div className="app">
      <Header cartItemCount={cartItemCount} />
      <main className="app__main">
        <ProductList products={products} onAddToCart={handleAddToCart} />
        <Cart cartItems={cart} onRemove={handleRemoveFromCart} onClear={handleClearCart} />
      </main>
      <Footer />
    </div>
  );
}

export default App;
