# Online Book Store (React + React Router)

Assignment 9.2.3 – DevOps and Fullstack. A Single Page Application with React Routing and lifecycle management using `useEffect()`.

## Step-by-step setup

### 1. Install the tools
- Node.js (LTS): https://nodejs.org
- Visual Studio Code: https://code.visualstudio.com

Check: `node -v` and `npm -v`

### 2. Create the project
If you are starting from scratch instead of using this folder:

```bash
npm create vite@latest online-book-store -- --template react
cd online-book-store
npm install
npm install react-router-dom
```

(This zip already contains the finished project, so you can skip to step 3.)

### 3. Install dependencies and start the server

```bash
cd online-book-store
npm install
npm run dev
```

Open http://localhost:5173

## Build order (follow this to understand/recreate the app)

| Step | File | What it does |
|------|------|--------------|
| 1 | `src/data/books.js` | Book data (B101–B106), categories, simulated `fetchBookById()` |
| 2 | `src/context/StoreContext.jsx` | Cart + recently viewed state (saved in localStorage) |
| 3 | `src/main.jsx` | Wraps app in `BrowserRouter` and `StoreProvider` |
| 4 | `src/components/Navigation.jsx` | `NavLink`s (no page reload) |
| 5 | `src/components/Header.jsx` | Title "Online Book Store" + navigation |
| 6 | `src/components/BookCard.jsx` | One book card with Link + Add to Cart |
| 7 | `src/components/BookList.jsx` | Search + category filter (`?category=` URL param) |
| 8 | `src/components/BookDetails.jsx` | `useParams`, `useEffect` lifecycle, loading, error, Prev/Next, `useNavigate` |
| 9 | `src/components/Category.jsx` | Category navigation |
| 10 | `src/components/Cart.jsx` | Add / remove / total |
| 11 | `src/components/Profile.jsx` + `RecentlyViewed.jsx` | Profile page, recently viewed books |
| 12 | `src/components/Home.jsx` | Landing page |
| 13 | `src/components/NotFound.jsx` | 404 page |
| 14 | `src/App.jsx` | Route configuration |
| 15 | `src/index.css` | Styling |

## Routes

| Path | Component |
|------|-----------|
| `/` | Home |
| `/books` | BookList |
| `/books/:bookId` | BookDetails |
| `/categories` | Category |
| `/cart` | Cart |
| `/profile` | Profile |
| `*` | NotFound (404) |

## Things to test (for your output screenshots)

1. Click through the nav links – the page never reloads.
2. Open `/books/B101`, `/books/B102`, `/books/B103` – a "Loading book details..." message shows first.
3. Open the browser console (F12) – you will see "Loading book details" on mount and "Leaving book details" when you leave or switch books (the cleanup).
4. Open `/books/B999` – error message with a Back button.
5. Open `/anything-else` – 404 page.
6. Use Previous / Next on the details page.
7. On `/books`, try the search box and the category dropdown.
8. Add and remove books in the cart; view recently viewed on Home or Profile.

## Lifecycle code (core of the assignment)

```jsx
useEffect(() => {
  console.log("Loading book details", bookId);
  // ...fetch book...
  return () => {
    console.log("Leaving book details", bookId); // cleanup
  };
}, [bookId]);
```
