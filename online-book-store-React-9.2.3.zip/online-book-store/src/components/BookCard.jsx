import { Link } from "react-router-dom";
import { useStore } from "../context/StoreContext.jsx";

export default function BookCard({ book }) {
  const { addToCart } = useStore();

  return (
    <div className="card">
      <div className="cover">{book.title.charAt(0)}</div>
      <span className="tag">{book.category}</span>
      <h3>{book.title}</h3>
      <p className="muted">by {book.author}</p>
      <p className="price">₹{book.price}</p>
      <div className="row">
        <Link className="btn btn-outline" to={`/books/${book.id}`}>
          View Details
        </Link>
        <button className="btn" onClick={() => addToCart(book.id)}>
          Add to Cart
        </button>
      </div>
    </div>
  );
}
