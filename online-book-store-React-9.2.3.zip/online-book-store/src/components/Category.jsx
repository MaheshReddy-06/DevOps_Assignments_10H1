import { Link } from "react-router-dom";
import { books, categories } from "../data/books.js";

export default function Category() {
  return (
    <section>
      <h2>Categories</h2>
      <div className="grid">
        {categories.map((c) => {
          const count = books.filter((b) => b.category === c).length;
          return (
            <Link
              key={c}
              className="card category-card"
              to={`/books?category=${encodeURIComponent(c)}`}
            >
              <h3>{c}</h3>
              <p className="muted">
                {count} book{count > 1 ? "s" : ""}
              </p>
            </Link>
          );
        })}
      </div>
    </section>
  );
}
