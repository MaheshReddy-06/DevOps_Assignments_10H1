import Navigation from "./Navigation.jsx";

export default function Header() {
  return (
    <header className="header">
      <div className="container header-inner">
        <h1 className="logo">Online Book Store</h1>
        <Navigation />
      </div>
    </header>
  );
}
