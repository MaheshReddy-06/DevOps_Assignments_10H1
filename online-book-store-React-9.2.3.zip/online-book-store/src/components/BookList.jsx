import { useState } from "react";
import { useSearchParams } from "react-router-dom";
import BookCard from "./BookCard.jsx";
import { books, categories } from "../data/books.js";

export default function BookList() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [query, setQuery] = useState("");

  // Category lives in the URL: /books?category=Web
  const category = searchParams.get("category") || "All";

  const filtered = books.filter((b) => {
    const matchesCategory = category === "All" || b.category === category;
    const q = query.trim().toLowerCase();
    const matchesSearch =
      !q ||
      b.title.toLowerCase().includes(q) ||
      b.author.toLowerCase().includes(q);
    return matchesCategory && matchesSearch;
  });

  function changeCategory(value) {
    if (value === "All") setSearchParams({});
    else setSearchParams({ category: value });
  }

  return (
    <section>
      <h2>Books</h2>

      <div className="toolbar">
        <input
          type="search"
          placeholder="Search by title or author..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
        <select value={category} onChange={(e) => changeCategory(e.target.value)}>
          <option value="All">All categories</option>
          {categories.map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </select>
      </div>

      {filtered.length === 0 ? (
        <p className="muted">No books match your search.</p>
      ) : (
        <div className="grid">
          {filtered.map((b) => (
            <BookCard key={b.id} book={b} />
          ))}
        </div>
      )}
    </section>
  );
}
