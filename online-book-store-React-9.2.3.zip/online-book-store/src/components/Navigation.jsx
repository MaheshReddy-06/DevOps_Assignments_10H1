import { NavLink } from "react-router-dom";
import { useStore } from "../context/StoreContext.jsx";

export default function Navigation() {
  const { cartCount } = useStore();

  return (
    <nav className="nav">
      <NavLink to="/" end>
        Home
      </NavLink>
      <NavLink to="/books">Books</NavLink>
      <NavLink to="/categories">Categories</NavLink>
      <NavLink to="/cart">Cart ({cartCount})</NavLink>
      <NavLink to="/profile">Profile</NavLink>
    </nav>
  );
}
