import { Link } from "react-router-dom";
import { useStore } from "../context/StoreContext.jsx";
import { getBook } from "../data/books.js";

export default function RecentlyViewed() {
  const { recent } = useStore();
  const items = recent.map(getBook).filter(Boolean);

  return (
    <section className="section">
      <h2>Recently Viewed</h2>
      {items.length === 0 ? (
        <p className="muted">You haven't viewed any books yet.</p>
      ) : (
        <ul className="chips">
          {items.map((b) => (
            <li key={b.id}>
              <Link to={`/books/${b.id}`}>{b.title}</Link>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
