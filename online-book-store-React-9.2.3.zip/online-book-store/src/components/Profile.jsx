import { useNavigate } from "react-router-dom";
import RecentlyViewed from "./RecentlyViewed.jsx";
import { useStore } from "../context/StoreContext.jsx";

export default function Profile() {
  const { cartCount } = useStore();
  const navigate = useNavigate();

  return (
    <section>
      <h2>Profile</h2>
      <div className="card profile">
        <div className="cover">B</div>
        <div>
          <h3>Book Lover</h3>
          <p className="muted">booklover@example.com</p>
          <p>Items in cart: {cartCount}</p>
        </div>
      </div>
      <RecentlyViewed />
      <button className="btn btn-outline" onClick={() => navigate("/")}>
        Log out
      </button>
    </section>
  );
}
