import { Link, useNavigate } from "react-router-dom";
import { useStore } from "../context/StoreContext.jsx";
import { getBook } from "../data/books.js";

export default function Cart() {
  const { cart, removeFromCart, clearCart } = useStore();
  const navigate = useNavigate();

  const lines = cart
    .map((item) => ({ ...item, book: getBook(item.id) }))
    .filter((line) => line.book);

  const total = lines.reduce((sum, l) => sum + l.book.price * l.qty, 0);

  if (lines.length === 0) {
    return (
      <section>
        <h2>Your Cart</h2>
        <p className="muted">Your cart is empty.</p>
        <button className="btn" onClick={() => navigate("/books")}>
          Browse Books
        </button>
      </section>
    );
  }

  return (
    <section>
      <h2>Your Cart</h2>
      <ul className="cart-list">
        {lines.map(({ book, qty }) => (
          <li key={book.id}>
            <div>
              <Link to={`/books/${book.id}`}>
                <strong>{book.title}</strong>
              </Link>
              <p className="muted">
                ₹{book.price} × {qty}
              </p>
            </div>
            <div className="row">
              <strong>₹{book.price * qty}</strong>
              <button className="btn btn-danger" onClick={() => removeFromCart(book.id)}>
                Remove
              </button>
            </div>
          </li>
        ))}
      </ul>
      <h3 className="total">Total: ₹{total}</h3>
      <div className="row">
        <button className="btn btn-outline" onClick={clearCart}>
          Clear Cart
        </button>
        <button className="btn" onClick={() => navigate("/books")}>
          Continue Shopping
        </button>
      </div>
    </section>
  );
}
