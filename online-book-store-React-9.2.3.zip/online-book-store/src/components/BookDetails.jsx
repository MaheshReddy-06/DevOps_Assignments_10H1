import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { useStore } from "../context/StoreContext.jsx";
import { books, fetchBookById } from "../data/books.js";

export default function BookDetails() {
  const { bookId } = useParams();
  const navigate = useNavigate();
  const { addToCart, addRecent } = useStore();

  const [book, setBook] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  // Lifecycle: runs on mount AND whenever bookId changes.
  useEffect(() => {
    let active = true;
    console.log("Loading book details", bookId);
    setLoading(true);
    setError("");
    setBook(null);

    fetchBookById(bookId)
      .then((data) => {
        if (!active) return;
        setBook(data);
        setLoading(false);
        addRecent(data.id);
      })
      .catch((err) => {
        if (!active) return;
        setError(err.message);
        setLoading(false);
      });

    // Cleanup: runs when bookId changes or the component unmounts.
    return () => {
      active = false;
      console.log("Leaving book details", bookId);
    };
  }, [bookId, addRecent]);

  const index = books.findIndex((b) => b.id === bookId);
  const prev = index > 0 ? books[index - 1] : null;
  const next = index >= 0 && index < books.length - 1 ? books[index + 1] : null;

  if (loading) {
    return <p className="status">Loading book details...</p>;
  }

  if (error) {
    return (
      <div className="status error">
        <h2>Something went wrong</h2>
        <p>{error}</p>
        <button className="btn" onClick={() => navigate("/books")}>
          Back to Books
        </button>
      </div>
    );
  }

  return (
    <section className="details">
      <button className="btn btn-outline" onClick={() => navigate(-1)}>
        ← Back
      </button>

      <div className="details-body">
        <div className="cover big">{book.title.charAt(0)}</div>
        <div>
          <span className="tag">{book.category}</span>
          <h2>{book.title}</h2>
          <p className="muted">by {book.author}</p>
          <p>{book.description}</p>
          <p className="price">₹{book.price}</p>
          <p className="muted">Book ID: {book.id}</p>
          <div className="row">
            <button className="btn" onClick={() => addToCart(book.id)}>
              Add to Cart
            </button>
            <Link
              className="btn btn-outline"
              to={`/books?category=${encodeURIComponent(book.category)}`}
            >
              More in {book.category}
            </Link>
          </div>
        </div>
      </div>

      <div className="pager">
        <button
          className="btn btn-outline"
          disabled={!prev}
          onClick={() => navigate(`/books/${prev.id}`)}
        >
          ← Previous
        </button>
        <button
          className="btn btn-outline"
          disabled={!next}
          onClick={() => navigate(`/books/${next.id}`)}
        >
          Next →
        </button>
      </div>
    </section>
  );
}
