import { Link } from "react-router-dom";
import BookCard from "./BookCard.jsx";
import RecentlyViewed from "./RecentlyViewed.jsx";
import { books } from "../data/books.js";

export default function Home() {
  return (
    <>
      <section className="hero">
        <h2>Welcome to the Online Book Store</h2>
        <p>Browse books, explore categories and build your reading cart.</p>
        <Link className="btn" to="/books">
          Browse All Books
        </Link>
      </section>

      <section className="section">
        <h2>Featured Books</h2>
        <div className="grid">
          {books.slice(0, 3).map((b) => (
            <BookCard key={b.id} book={b} />
          ))}
        </div>
      </section>

      <RecentlyViewed />
    </>
  );
}
