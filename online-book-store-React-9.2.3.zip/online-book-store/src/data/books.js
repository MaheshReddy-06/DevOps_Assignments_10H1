export const books = [
  {
    id: "B101",
    title: "Python Programming",
    author: "A. Sharma",
    category: "Programming",
    price: 499,
    description:
      "A beginner-friendly guide to Python: syntax, data structures, functions, files and small projects.",
  },
  {
    id: "B102",
    title: "Web Development",
    author: "R. Verma",
    category: "Web",
    price: 599,
    description:
      "HTML, CSS, JavaScript and React fundamentals for building modern single page applications.",
  },
  {
    id: "B103",
    title: "Machine Learning",
    author: "S. Iyer",
    category: "AI & ML",
    price: 799,
    description:
      "Core machine learning concepts: regression, classification, clustering and model evaluation.",
  },
  {
    id: "B104",
    title: "Data Structures in Java",
    author: "K. Reddy",
    category: "Programming",
    price: 549,
    description:
      "Arrays, linked lists, trees, graphs and hashing, explained with Java examples.",
  },
  {
    id: "B105",
    title: "Database Systems",
    author: "M. Rao",
    category: "Databases",
    price: 649,
    description:
      "Relational design, SQL, normalization, transactions and an introduction to NoSQL.",
  },
  {
    id: "B106",
    title: "Deep Learning Basics",
    author: "P. Nair",
    category: "AI & ML",
    price: 899,
    description:
      "Neural networks, backpropagation, CNNs and RNNs with practical examples.",
  },
];

export const categories = [...new Set(books.map((b) => b.category))];

// Simulates a network call so loading and error states can be demonstrated.
export function fetchBookById(id) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      const book = books.find((b) => b.id === id);
      if (book) resolve(book);
      else reject(new Error(`No book found with id "${id}".`));
    }, 700);
  });
}

export function getBook(id) {
  return books.find((b) => b.id === id);
}
