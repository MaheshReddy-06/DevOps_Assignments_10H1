# Student Attendance Management System

Assignment 9.1.2 – Scenario 2: College Student Attendance Dashboard
Course: DevOps and Fullstack (23CS102PE405)

A React app that lets faculty view students, mark them Present/Absent, and see who is eligible
(attendance >= 75%) for examinations.

## Run it

```bash
npm install
npm run dev        # open the URL shown (usually http://localhost:5173)
npm run build      # optional production build
```

Requires Node.js 18+.

## Structure

```
src/
  App.jsx                 state (useState), event handlers, search, summary counts
  components/
    Header.jsx            application title
    StudentList.jsx       maps over students -> StudentCard
    StudentCard.jsx       one student: name, roll no, branch, eligibility badge
    Attendance.jsx        percentage, progress bar, Present/Absent buttons
    Summary.jsx           total / present / absent / eligible / not eligible
  data/students.js        sample student data
  utils/attendance.js     percentage + eligibility helpers
```

## Where each requirement is covered

- **Props**: `StudentList` -> `StudentCard` (student details), `StudentCard` -> `Attendance`
  (percentage, status), `App` -> `Summary` (summary object), and event handlers
  (`onMark`, `onPresent`, `onAbsent`) are passed from parent to child.
- **State (`useState`)**: `students` (attendance and today's mark) and `search`.
- **Present/Absent**: Present adds a class attended and a class held; Absent adds only a class
  held. The percentage is recalculated each render, so changing a mark never double counts.
- **Conditional rendering**: `attendance >= 75 ? "Eligible" : "Not Eligible"`.
- **Advanced**: `.map()` for lists, highlighted cards below 75%, live summary,
  Mark All Present / Mark All Absent.
- **Bonus**: search (name or roll number), Reset Attendance, present/absent/eligible counts.
