import { useState } from "react";
import Header from "./components/Header.jsx";
import Summary from "./components/Summary.jsx";
import StudentList from "./components/StudentList.jsx";
import { initialStudents } from "./data/students.js";
import { isEligible } from "./utils/attendance.js";

export default function App() {
  // State: all students (with today's Present/Absent mark) and the search text.
  const [students, setStudents] = useState(initialStudents);
  const [search, setSearch] = useState("");

  // Event handlers (passed down to child components as props).
  const markStudent = (id, status) => {
    setStudents((prev) =>
      prev.map((s) => (s.id === id ? { ...s, status } : s))
    );
  };

  const markAll = (status) => {
    setStudents((prev) => prev.map((s) => ({ ...s, status })));
  };

  const resetAttendance = () => {
    setStudents((prev) => prev.map((s) => ({ ...s, status: null })));
  };

  // Derived values for the summary.
  const summary = {
    total: students.length,
    present: students.filter((s) => s.status === "Present").length,
    absent: students.filter((s) => s.status === "Absent").length,
    eligible: students.filter(isEligible).length,
    notEligible: students.filter((s) => !isEligible(s)).length,
  };

  // Search by name or roll number.
  const query = search.trim().toLowerCase();
  const visibleStudents = students.filter(
    (s) =>
      s.name.toLowerCase().includes(query) ||
      s.rollNo.toLowerCase().includes(query)
  );

  return (
    <div className="app">
      <Header title="Student Attendance Management System" />

      <Summary summary={summary} />

      <div className="toolbar">
        <input
          className="search"
          type="text"
          placeholder="Search by name or roll number..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <button className="btn btn-present" onClick={() => markAll("Present")}>
          Mark All Present
        </button>
        <button className="btn btn-absent" onClick={() => markAll("Absent")}>
          Mark All Absent
        </button>
        <button className="btn btn-reset" onClick={resetAttendance}>
          Reset Attendance
        </button>
      </div>

      <StudentList students={visibleStudents} onMark={markStudent} />
    </div>
  );
}
