import StudentCard from "./StudentCard.jsx";

export default function StudentList({ students, onMark }) {
  if (students.length === 0) {
    return <p className="empty">No students match your search.</p>;
  }

  return (
    <div className="student-list">
      {students.map((student) => (
        <StudentCard key={student.id} student={student} onMark={onMark} />
      ))}
    </div>
  );
}
