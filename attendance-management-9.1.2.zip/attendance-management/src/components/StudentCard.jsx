import Attendance from "./Attendance.jsx";
import { getPercentage, isEligible } from "../utils/attendance.js";

export default function StudentCard({ student, onMark }) {
  const { id, name, rollNo, branch, status } = student;
  const percentage = getPercentage(student);
  const eligible = isEligible(student);

  return (
    // Students below 75% are highlighted with the "low" class.
    <div className={`card ${eligible ? "" : "low"}`}>
      <div className="card-top">
        <div>
          <h3>{name}</h3>
          <p className="muted">
            {rollNo} &middot; {branch}
          </p>
        </div>
        <span className={`badge ${eligible ? "ok" : "bad"}`}>
          {eligible ? "Eligible" : "Not Eligible"}
        </span>
      </div>

      <Attendance
        percentage={percentage}
        status={status}
        onPresent={() => onMark(id, "Present")}
        onAbsent={() => onMark(id, "Absent")}
      />
    </div>
  );
}
