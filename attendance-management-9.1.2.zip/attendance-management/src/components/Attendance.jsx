export default function Attendance({ percentage, status, onPresent, onAbsent }) {
  return (
    <div className="attendance">
      <div className="percent-row">
        <span>Attendance: <strong>{percentage}%</strong></span>
        <span className="muted">
          Today: {status ? status : "Not marked"}
        </span>
      </div>

      <div className="bar">
        <div
          className={`bar-fill ${percentage >= 75 ? "ok" : "bad"}`}
          style={{ width: `${percentage}%` }}
        />
      </div>

      <div className="actions">
        <button
          className={`btn btn-present ${status === "Present" ? "active" : ""}`}
          onClick={onPresent}
        >
          Present
        </button>
        <button
          className={`btn btn-absent ${status === "Absent" ? "active" : ""}`}
          onClick={onAbsent}
        >
          Absent
        </button>
      </div>
    </div>
  );
}
