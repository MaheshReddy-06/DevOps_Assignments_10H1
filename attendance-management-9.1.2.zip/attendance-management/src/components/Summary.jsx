export default function Summary({ summary }) {
  const { total, present, absent, eligible, notEligible } = summary;

  return (
    <section className="summary">
      <div className="stat">
        <span className="num">{total}</span>
        <span className="label">Total Students</span>
      </div>
      <div className="stat present">
        <span className="num">{present}</span>
        <span className="label">Present</span>
      </div>
      <div className="stat absent">
        <span className="num">{absent}</span>
        <span className="label">Absent</span>
      </div>
      <div className="stat eligible">
        <span className="num">{eligible}</span>
        <span className="label">Eligible</span>
      </div>
      <div className="stat not-eligible">
        <span className="num">{notEligible}</span>
        <span className="label">Not Eligible</span>
      </div>
    </section>
  );
}
