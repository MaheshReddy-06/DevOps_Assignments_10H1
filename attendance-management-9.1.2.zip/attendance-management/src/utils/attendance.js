export const ELIGIBLE_THRESHOLD = 75;

// Exact attendance % including today's mark (if any).
// Present -> attended + held both go up by 1; Absent -> only held goes up.
function getExactPercentage(student) {
  const held = student.classesHeld + (student.status ? 1 : 0);
  const attended =
    student.classesAttended + (student.status === "Present" ? 1 : 0);
  return (attended / held) * 100;
}

// Rounded value for display.
export function getPercentage(student) {
  return Math.round(getExactPercentage(student));
}

// Eligibility uses the exact value, so 74.6% is not rounded up to 75%.
export function isEligible(student) {
  return getExactPercentage(student) >= ELIGIBLE_THRESHOLD;
}
