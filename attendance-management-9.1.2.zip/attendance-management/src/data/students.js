// Sample student data.
// attendance = percentage before today's session (classesHeld = 100 keeps the maths simple).
// The first three students are the examples from the assignment sheet.
export const initialStudents = [
  { id: 1, name: "Rahul", rollNo: "CSE101", branch: "CSE", attendance: 82 },
  { id: 2, name: "Priya", rollNo: "CSE102", branch: "CSE", attendance: 68 },
  { id: 3, name: "Arjun", rollNo: "CSE103", branch: "CSE", attendance: 91 },
  { id: 4, name: "Sneha", rollNo: "CSE104", branch: "CSE", attendance: 74 },
  { id: 5, name: "Karthik", rollNo: "ECE101", branch: "ECE", attendance: 77 },
  { id: 6, name: "Divya", rollNo: "ECE102", branch: "ECE", attendance: 59 },
].map((s) => ({
  ...s,
  classesHeld: 100,
  classesAttended: s.attendance, // attended out of 100
  status: null, // today's mark: null | "Present" | "Absent"
}));
